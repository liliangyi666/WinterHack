/**
 * Qwen3-Omni 音频管理器
 *
 * 功能：
 * - PCM 格式录音管理
 * - 实时音频流发送
 * - AI 音频接收与播放
 * - 音频缓冲队列管理
 * - 打断功能支持
 *
 * @class OmniAudioManager
 * @date 2025-10-20
 */

const PCMConverter = require('./pcm-converter.js');

class OmniAudioManager {
  /**
   * 构造函数
   * @param {Object} omniWebSocket - OmniWebSocket 实例
   */
  constructor(omniWebSocket) {
    if (!omniWebSocket) {
      throw new Error('OmniWebSocket 实例不能为空');
    }

    this.omniWS = omniWebSocket;
    this.recorderManager = wx.getRecorderManager();
    this.innerAudioContext = wx.createInnerAudioContext();
    this.pcmConverter = new PCMConverter();

    this.isRecording = false;
    this.isPlaying = false;
    this.audioBuffer = [];
    this.tempFiles = [];

    this._initRecorder();
    this._initPlayer();

    console.log('[OmniAudio] 音频管理器已初始化');
  }

  /**
   * 初始化录音管理器
   * @private
   */
  _initRecorder() {
    this.recorderManager.onStart(() => {
      console.log('[OmniAudio] 录音开始回调触发');
      // isRecording 已经在 startRecording() 中设置为 true

      if (this.isPlaying) {
        console.log('[OmniAudio] 检测到正在播放，触发打断');
        this.omniWS.interrupt();
        this.stopPlaying();
      }
    });

    this.recorderManager.onFrameRecorded((res) => {
      console.log('[OmniAudio] ✅ onFrameRecorded 触发');

      if (!this.isRecording) {
        console.log('[OmniAudio] ⚠️ 未在录音状态，跳过');
        return;
      }

      const { frameBuffer } = res;
      console.log(`[OmniAudio] 音频帧大小: ${frameBuffer ? frameBuffer.byteLength : 0} bytes`);

      if (!frameBuffer || frameBuffer.byteLength === 0) {
        console.warn('[OmniAudio] 录音帧为空');
        return;
      }

      try {
        const base64 = wx.arrayBufferToBase64(frameBuffer);
        console.log(`[OmniAudio] Base64长度: ${base64.length}`);
        this.omniWS.sendAudio(base64);
        console.log('[OmniAudio] ✅ 音频帧已发送');
      } catch (err) {
        console.error('[OmniAudio] 音频帧发送失败:', err);
      }
    });

    this.recorderManager.onStop((res) => {
      console.log('[OmniAudio] 录音结束');
      this.isRecording = false;

      const { tempFilePath, duration, fileSize } = res;
      console.log(`[OmniAudio] 录音时长: ${duration}ms, 文件大小: ${fileSize} bytes`);
      console.log(`[OmniAudio] 录音文件: ${tempFilePath}`);

      // 发送录音结束信号到后端，触发AI响应
      console.log('[OmniAudio] 发送录音结束信号');
      this.omniWS.send({ type: 'audio_end' });

      if (this.onRecordingComplete) {
        this.onRecordingComplete({
          tempFilePath,
          duration: Math.round(duration / 1000),
          fileSize
        });
      }
    });

    this.recorderManager.onError((err) => {
      console.error('[OmniAudio] 录音错误:', err);
      this.isRecording = false;

      const errorMessage = this._getRecorderErrorMessage(err.errCode);

      wx.showToast({
        title: errorMessage,
        icon: 'none',
        duration: 2000
      });
    });

    this.recorderManager.onInterruptionBegin(() => {
      console.warn('[OmniAudio] 录音被打断（来电等）');
      this.stopRecording();
    });

    this.recorderManager.onInterruptionEnd(() => {
      console.log('[OmniAudio] 录音打断结束');
    });
  }

  /**
   * 初始化播放器
   * @private
   */
  _initPlayer() {
    this.innerAudioContext.onEnded(() => {
      console.log('[OmniAudio] 当前音频播放结束');
      this.isPlaying = false;
      // 立即检查是否还有音频块需要播放
      if (this.audioBuffer.length > 0) {
        this._playMergedChunks();
      }
    });

    this.innerAudioContext.onError((err) => {
      console.error('[OmniAudio] 播放错误:', err);
      this.isPlaying = false;

      wx.showToast({
        title: '音频播放失败',
        icon: 'none',
        duration: 1500
      });

      this._playNextChunk();
    });

    this.innerAudioContext.onStop(() => {
      console.log('[OmniAudio] 播放已停止');
      this.isPlaying = false;
    });

    this.innerAudioContext.onPause(() => {
      console.log('[OmniAudio] 播放已暂停');
    });

    this.innerAudioContext.onPlay(() => {
      console.log('[OmniAudio] 播放已开始');
      this.isPlaying = true;
    });
  }

  /**
   * 开始录音
   * @param {Object} options - 录音配置
   * @param {string} options.format - 音频格式（默认：PCM）
   * @param {number} options.sampleRate - 采样率（默认：16000）
   * @param {number} options.numberOfChannels - 声道数（默认：1）
   * @param {number} options.frameSize - 帧大小（默认：10，约200ms）
   */
  startRecording(options = {}) {
    try {
      const recordOptions = {
        format: options.format || 'PCM',
        sampleRate: options.sampleRate || 16000,
        numberOfChannels: options.numberOfChannels || 1,
        frameSize: options.frameSize || 10
      };

      console.log('[OmniAudio] 开始录音，配置:', recordOptions);

      // ✅ 在调用 start() 之前设置 isRecording，防止 onFrameRecorded 先触发
      this.isRecording = true;

      this.recorderManager.start(recordOptions);

    } catch (err) {
      console.error('[OmniAudio] 启动录音失败:', err);
      this.isRecording = false;
      wx.showToast({
        title: '录音启动失败',
        icon: 'none',
        duration: 2000
      });
    }
  }

  /**
   * 停止录音
   */
  stopRecording() {
    if (this.isRecording) {
      try {
        this.recorderManager.stop();
        console.log('[OmniAudio] 停止录音');
      } catch (err) {
        console.error('[OmniAudio] 停止录音失败:', err);
      }
    } else {
      console.warn('[OmniAudio] 未在录音，无需停止');
    }
  }

  /**
   * 暂停录音
   */
  pauseRecording() {
    if (this.isRecording) {
      try {
        this.recorderManager.pause();
        console.log('[OmniAudio] 暂停录音');
      } catch (err) {
        console.error('[OmniAudio] 暂停录音失败:', err);
      }
    }
  }

  /**
   * 恢复录音
   */
  resumeRecording() {
    try {
      this.recorderManager.resume();
      console.log('[OmniAudio] 恢复录音');
    } catch (err) {
      console.error('[OmniAudio] 恢复录音失败:', err);
    }
  }

  /**
   * 添加音频块到播放队列
   * @param {string} pcmBase64 - Base64 编码的 PCM 音频数据
   * @param {number} sampleRate - 采样率（默认：24000）
   */
  addAudioChunk(pcmBase64, sampleRate = 24000) {
    if (!pcmBase64) {
      console.warn('[OmniAudio] 音频块为空，跳过');
      return;
    }

    try {
      const validation = this.pcmConverter.validatePCMData(pcmBase64);
      if (!validation.valid) {
        console.error('[OmniAudio] PCM数据验证失败:', validation.message);
        return;
      }

      // 直接存储 PCM Base64，等待合并
      this.audioBuffer.push({
        pcm: pcmBase64,
        sampleRate: sampleRate
      });

      // 如果当前没有播放，立即开始播放（不等待更多块）
      if (!this.isPlaying) {
        this._playMergedChunks();
      }

    } catch (err) {
      console.error('[OmniAudio] 添加音频块失败:', err);
    }
  }

  /**
   * 合并播放音频块（减少间隔，提高流畅度）
   * @private
   */
  _playMergedChunks() {
    if (this.audioBuffer.length === 0) {
      this.isPlaying = false;
      console.log('[OmniAudio] 队列为空，停止播放');
      return;
    }

    if (this.isPlaying) {
      console.log('[OmniAudio] 正在播放，等待当前音频结束');
      return;
    }

    // 取出队列中的所有音频块（最多5个，避免延迟过长）
    const maxChunks = Math.min(5, this.audioBuffer.length);
    const chunks = this.audioBuffer.splice(0, maxChunks);

    console.log(`[OmniAudio] 合并播放 ${chunks.length} 个音频块，剩余队列: ${this.audioBuffer.length}`);

    // 将多个 PCM 块合并
    const mergedPCM = this._mergePCMChunks(chunks);

    if (!mergedPCM) {
      console.error('[OmniAudio] 合并音频块失败');
      this.isPlaying = false;
      return;
    }

    // 转换为 WAV
    const wavBase64 = this.pcmConverter.pcmToWav(mergedPCM, chunks[0].sampleRate);

    const fs = wx.getFileSystemManager();
    const tempFilePath = `${wx.env.USER_DATA_PATH}/temp_audio_${Date.now()}.wav`;

    fs.writeFile({
      filePath: tempFilePath,
      data: wavBase64,
      encoding: 'base64',
      success: () => {
        console.log('[OmniAudio] 合并音频文件写入成功');
        this.tempFiles.push(tempFilePath);

        this.innerAudioContext.src = tempFilePath;
        this.innerAudioContext.play();
      },
      fail: (err) => {
        console.error('[OmniAudio] 写入临时文件失败:', err);
        this.isPlaying = false;
        this._playMergedChunks();
      }
    });
  }

  /**
   * 合并多个 PCM Base64 音频块
   * @private
   * @param {Array} chunks - 音频块数组
   * @returns {string} 合并后的 PCM Base64
   */
  _mergePCMChunks(chunks) {
    try {
      // 将所有 Base64 转换为 ArrayBuffer
      const buffers = chunks.map(chunk => {
        const binaryString = wx.base64ToArrayBuffer(chunk.pcm);
        return new Uint8Array(binaryString);
      });

      // 计算总长度
      const totalLength = buffers.reduce((sum, buf) => sum + buf.length, 0);

      // 创建合并后的 ArrayBuffer
      const mergedBuffer = new Uint8Array(totalLength);
      let offset = 0;

      buffers.forEach(buf => {
        mergedBuffer.set(buf, offset);
        offset += buf.length;
      });

      // 转换回 Base64
      return wx.arrayBufferToBase64(mergedBuffer.buffer);

    } catch (err) {
      console.error('[OmniAudio] 合并 PCM 块失败:', err);
      return null;
    }
  }

  /**
   * 播放下一个音频块（保留旧方法作为备用）
   * @private
   */
  _playNextChunk() {
    // 现在使用 _playMergedChunks 替代
    this._playMergedChunks();
  }

  /**
   * 停止播放并清空队列
   */
  stopPlaying() {
    console.log('[OmniAudio] 停止播放并清空队列');

    try {
      this.innerAudioContext.stop();
    } catch (err) {
      console.error('[OmniAudio] 停止播放失败:', err);
    }

    this.audioBuffer = [];
    this.isPlaying = false;

    this._cleanupTempFiles();
  }

  /**
   * 暂停播放
   */
  pausePlaying() {
    if (this.isPlaying) {
      try {
        this.innerAudioContext.pause();
        console.log('[OmniAudio] 播放已暂停');
      } catch (err) {
        console.error('[OmniAudio] 暂停播放失败:', err);
      }
    }
  }

  /**
   * 恢复播放
   */
  resumePlaying() {
    try {
      this.innerAudioContext.play();
      console.log('[OmniAudio] 播放已恢复');
    } catch (err) {
      console.error('[OmniAudio] 恢复播放失败:', err);
    }
  }

  /**
   * 清理临时音频文件
   * @private
   */
  _cleanupTempFiles() {
    if (this.tempFiles.length === 0) {
      return;
    }

    console.log(`[OmniAudio] 清理 ${this.tempFiles.length} 个临时文件`);

    const fs = wx.getFileSystemManager();
    const files = [...this.tempFiles];
    this.tempFiles = [];

    files.forEach(filePath => {
      try {
        fs.unlinkSync(filePath);
        console.log('[OmniAudio] 已删除临时文件:', filePath);
      } catch (err) {
        console.error('[OmniAudio] 删除临时文件失败:', filePath, err);
      }
    });
  }

  /**
   * 销毁音频管理器
   */
  destroy() {
    console.log('[OmniAudio] 销毁音频管理器');

    this.stopRecording();
    this.stopPlaying();

    try {
      this.innerAudioContext.destroy();
    } catch (err) {
      console.error('[OmniAudio] 销毁播放器失败:', err);
    }

    this._cleanupTempFiles();

    this.audioBuffer = [];
    this.isRecording = false;
    this.isPlaying = false;

    console.log('[OmniAudio] 音频管理器已销毁');
  }

  /**
   * 获取录音状态
   * @returns {Object} 录音状态信息
   */
  getRecordingStatus() {
    return {
      isRecording: this.isRecording,
      isPlaying: this.isPlaying,
      bufferLength: this.audioBuffer.length
    };
  }

  /**
   * 获取播放状态
   * @returns {Object} 播放状态信息
   */
  getPlayingStatus() {
    return {
      isPlaying: this.isPlaying,
      bufferLength: this.audioBuffer.length,
      duration: this.innerAudioContext.duration || 0,
      currentTime: this.innerAudioContext.currentTime || 0
    };
  }

  /**
   * 获取录音错误消息
   * @param {number} errCode - 错误代码
   * @returns {string} 错误消息
   * @private
   */
  _getRecorderErrorMessage(errCode) {
    const errorMessages = {
      10001: '未获得录音权限',
      10002: '录音文件创建失败',
      10003: '上次录音还未结束',
      10004: '录音已经在进行中',
      10005: '录音失败',
      10006: '录音文件不存在'
    };

    return errorMessages[errCode] || `录音失败 (错误代码: ${errCode})`;
  }

  /**
   * 设置音量
   * @param {number} volume - 音量（0-1）
   */
  setVolume(volume) {
    if (volume < 0 || volume > 1) {
      console.error('[OmniAudio] 音量必须在0-1之间');
      return;
    }

    this.innerAudioContext.volume = volume;
    console.log('[OmniAudio] 音量已设置为:', volume);
  }

  /**
   * 获取音量
   * @returns {number} 当前音量（0-1）
   */
  getVolume() {
    return this.innerAudioContext.volume;
  }
}

module.exports = OmniAudioManager;
