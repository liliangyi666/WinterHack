/**
 * Qwen3-Omni WebSocket 客户端管理器
 *
 * 功能：
 * - WebSocket 连接管理
 * - 自动重连机制
 * - 心跳检测
 * - 消息队列（断线时缓存）
 * - 消息路由
 *
 * @class OmniWebSocket
 * @date 2025-10-20
 */

class OmniWebSocket {
  /**
   * 构造函数
   * @param {Object} options - 配置选项
   * @param {string} options.url - WebSocket服务器地址
   * @param {number} options.reconnectInterval - 重连间隔（毫秒）
   * @param {number} options.heartbeatInterval - 心跳间隔（毫秒）
   * @param {number} options.maxReconnectAttempts - 最大重连次数
   */
  constructor(options = {}) {
    this.url = options.url || 'wss://ofwaa.org/ws/omni';
    this.reconnectInterval = options.reconnectInterval || 3000;
    this.heartbeatInterval = options.heartbeatInterval || 30000;
    this.maxReconnectAttempts = options.maxReconnectAttempts || 5;

    this.ws = null;
    this.isConnected = false;
    this.isReconnecting = false;
    this.reconnectAttempts = 0;
    this.messageQueue = [];
    this.heartbeatTimer = null;
    this.reconnectTimer = null;
    this.sessionCheckTimer = null;  // 会话超时检查定时器

    this.dialectType = '';
    this.voice = '';
    this.lastActivityTime = 0;  // 最后活动时间（用于检测连接超时）
    this.sessionTimeoutMs = 50000;  // Omni会话超时阈值（50秒，留10秒缓冲）
    this.sessionTimeoutWarned = false;  // 是否已发出超时警告

    this.onInitialized = null;
    this.onUserText = null;
    this.onAIText = null;
    this.onAIAudio = null;
    this.onResponseDone = null;  // AI响应完成回调
    this.onError = null;
    this.onClose = null;
  }

  /**
   * 连接到 WebSocket 服务器
   * @param {string} dialectType - 方言类型（如：四川话）
   * @param {string} voice - 音色ID（如：Sunny）
   * @returns {Promise<void>}
   */
  connect(dialectType, voice) {
    return new Promise((resolve, reject) => {
      this.dialectType = dialectType;
      this.voice = voice;

      console.log(`[OmniWS] 正在连接: ${this.url}`);
      console.log(`[OmniWS] 方言: ${dialectType}, 音色: ${voice}`);

      try {
        this.ws = wx.connectSocket({
          url: this.url,
          success: () => {
            console.log('[OmniWS] Socket创建成功');
          },
          fail: (err) => {
            console.error('[OmniWS] Socket创建失败:', err);
            reject(new Error('WebSocket创建失败'));
          }
        });

        this.ws.onOpen(() => {
          console.log('[OmniWS] 连接成功');
          this.isConnected = true;
          this.isReconnecting = false;
          this.reconnectAttempts = 0;
          this.lastActivityTime = Date.now();  // 记录连接时间

          this._startHeartbeat();

          this.send({
            type: 'init',
            dialect: dialectType,
            voice: voice
          });

          this._flushMessageQueue();

          resolve();
        });

        this.ws.onMessage((event) => {
          try {
            const message = JSON.parse(event.data);

            // 更新最后活动时间（接收到任何消息都算活动）
            this.lastActivityTime = Date.now();
            this.sessionTimeoutWarned = false;  // 重置警告标志

            this._handleMessage(message);
          } catch (err) {
            console.error('[OmniWS] 消息解析失败:', err);
          }
        });

        this.ws.onError((err) => {
          console.error('[OmniWS] 错误:', err);
          this.isConnected = false;
          this._stopHeartbeat();
          this._stopSessionCheck();

          if (this.onError) {
            this.onError(err);
          }

          this._attemptReconnect();
        });

        this.ws.onClose(() => {
          console.log('[OmniWS] 连接关闭');
          this.isConnected = false;
          this._stopHeartbeat();
          this._stopSessionCheck();

          if (this.onClose) {
            this.onClose();
          }

          if (!this.isReconnecting) {
            this._attemptReconnect();
          }
        });

      } catch (err) {
        console.error('[OmniWS] 连接异常:', err);
        reject(err);
      }
    });
  }

  /**
   * 发送消息
   * @param {Object} message - 消息对象
   * @returns {boolean} 是否成功发送
   */
  send(message) {
    // 检查连接状态
    if (!this.isConnected || !this.ws) {
      console.warn('[OmniWS] 未连接，消息已加入队列:', message.type);
      this.messageQueue.push(message);
      return false;
    }

    // 检查WebSocket readyState
    // readyState: 0=CONNECTING, 1=OPEN, 2=CLOSING, 3=CLOSED
    const readyState = this.ws.readyState || 0;
    if (readyState !== 1) {
      console.error(`[OmniWS] 连接状态异常 (readyState=${readyState})，无法发送消息`);

      if (readyState === 3) {  // CLOSED
        this.isConnected = false;
        wx.showToast({
          title: '连接已断开，正在重连...',
          icon: 'none',
          duration: 2000
        });

        // 触发自动重连
        this._attemptReconnect();
      }

      this.messageQueue.push(message);
      return false;
    }

    // 检查会话超时（50秒警告，60秒超时）
    const timeSinceLastActivity = Date.now() - this.lastActivityTime;
    if (timeSinceLastActivity > this.sessionTimeoutMs) {
      console.warn(`[OmniWS] ⚠️ 会话即将超时（已${Math.floor(timeSinceLastActivity / 1000)}秒无活动）`);
      wx.showToast({
        title: '连接即将超时，请尽快操作',
        icon: 'none',
        duration: 2000
      });
    }

    // 发送消息
    try {
      this.ws.send({
        data: JSON.stringify(message),
        success: () => {
          console.log('[OmniWS] 消息发送成功:', message.type);
        },
        fail: (err) => {
          console.error('[OmniWS] 消息发送失败:', err);
          this.isConnected = false;
          this.messageQueue.push(message);
          this._attemptReconnect();
        }
      });
      return true;
    } catch (err) {
      console.error('[OmniWS] 发送异常:', err);
      this.isConnected = false;
      this.messageQueue.push(message);
      this._attemptReconnect();
      return false;
    }
  }

  /**
   * 发送音频数据
   * @param {string} audioBase64 - Base64编码的PCM音频数据
   */
  sendAudio(audioBase64) {
    this.lastActivityTime = Date.now();  // 更新活动时间
    this.send({
      type: 'audio',
      data: audioBase64
    });
  }

  /**
   * 发送打断信号
   */
  interrupt() {
    this.send({
      type: 'interrupt'
    });
  }

  /**
   * 发送心跳
   * @private
   */
  _sendHeartbeat() {
    this.send({
      type: 'ping'
    });
  }

  /**
   * 启动心跳检测
   * @private
   */
  _startHeartbeat() {
    this._stopHeartbeat();

    this.heartbeatTimer = setInterval(() => {
      if (this.isConnected) {
        this._sendHeartbeat();
      }
    }, this.heartbeatInterval);

    console.log('[OmniWS] 心跳检测已启动');

    // 同时启动会话超时检查
    this._startSessionCheck();
  }

  /**
   * 启动会话超时检查
   * @private
   */
  _startSessionCheck() {
    this._stopSessionCheck();

    this.sessionCheckTimer = setInterval(() => {
      if (!this.isConnected) {
        return;
      }

      const timeSinceLastActivity = Date.now() - this.lastActivityTime;
      const secondsSinceActivity = Math.floor(timeSinceLastActivity / 1000);

      // 50秒警告
      if (timeSinceLastActivity > this.sessionTimeoutMs && !this.sessionTimeoutWarned) {
        console.warn(`[OmniWS] ⚠️ 会话接近超时（${secondsSinceActivity}秒无活动）`);
        wx.showToast({
          title: `连接将在${60 - secondsSinceActivity}秒后超时`,
          icon: 'none',
          duration: 3000
        });
        this.sessionTimeoutWarned = true;
      }

      // 60秒超时（预防性重连）
      if (timeSinceLastActivity > 60000) {
        console.error(`[OmniWS] ❌ 会话已超时（${secondsSinceActivity}秒无活动），主动重连`);
        this.sessionTimeoutWarned = false;
        this.close();
        this._attemptReconnect();
      }
    }, 5000);  // 每5秒检查一次

    console.log('[OmniWS] 会话超时检查已启动');
  }

  /**
   * 停止会话超时检查
   * @private
   */
  _stopSessionCheck() {
    if (this.sessionCheckTimer) {
      clearInterval(this.sessionCheckTimer);
      this.sessionCheckTimer = null;
      this.sessionTimeoutWarned = false;
      console.log('[OmniWS] 会话超时检查已停止');
    }
  }

  /**
   * 停止心跳检测
   * @private
   */
  _stopHeartbeat() {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
      console.log('[OmniWS] 心跳检测已停止');
    }
  }

  /**
   * 刷新消息队列（发送缓存的消息）
   * @private
   */
  _flushMessageQueue() {
    if (this.messageQueue.length > 0) {
      console.log(`[OmniWS] 发送队列中的 ${this.messageQueue.length} 条消息`);
      const queue = [...this.messageQueue];
      this.messageQueue = [];

      queue.forEach(message => {
        this.send(message);
      });
    }
  }

  /**
   * 尝试重连
   * @private
   */
  _attemptReconnect() {
    if (this.isReconnecting) {
      return;
    }

    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error('[OmniWS] 达到最大重连次数，停止重连');
      wx.showToast({
        title: '连接失败，请重试',
        icon: 'none',
        duration: 2000
      });
      return;
    }

    this.isReconnecting = true;
    this.reconnectAttempts++;

    console.log(`[OmniWS] 尝试重连 (${this.reconnectAttempts}/${this.maxReconnectAttempts})...`);

    this.reconnectTimer = setTimeout(() => {
      this.connect(this.dialectType, this.voice).catch(err => {
        console.error('[OmniWS] 重连失败:', err);
        this.isReconnecting = false;
      });
    }, this.reconnectInterval);
  }

  /**
   * 处理接收到的消息
   * @param {Object} message - 消息对象
   * @private
   */
  _handleMessage(message) {
    const { type } = message;

    switch (type) {
      case 'initialized':
        console.log('[OmniWS] 会话初始化成功');
        if (this.onInitialized) {
          this.onInitialized(message);
        }
        break;

      case 'user_text':
        console.log('[OmniWS] 用户文本:', message.data);
        if (this.onUserText) {
          this.onUserText(message.data);
        }
        break;

      case 'ai_text':
        console.log('[OmniWS] AI文本:', message.data);
        if (this.onAIText) {
          this.onAIText(message.data);
        }
        break;

      case 'ai_audio':
        console.log('[OmniWS] AI音频块:', message.data ? `${message.data.length} chars` : '0 chars');
        if (this.onAIAudio) {
          this.onAIAudio(message.data);
        }
        break;

      case 'response_done':
        console.log('[OmniWS] AI响应完成');
        if (this.onResponseDone) {
          this.onResponseDone();
        }
        break;

      case 'pong':
        console.log('[OmniWS] 心跳响应');
        break;

      case 'error':
        console.error('[OmniWS] 服务器错误:', message.error || message.message);
        if (this.onError) {
          this.onError(message.error || message.message);
        }
        wx.showToast({
          title: '服务器错误',
          icon: 'none',
          duration: 2000
        });
        break;

      default:
        console.warn('[OmniWS] 未知消息类型:', type);
        break;
    }
  }

  /**
   * 关闭连接
   */
  close() {
    console.log('[OmniWS] 主动关闭连接');

    this._stopHeartbeat();
    this._stopSessionCheck();

    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }

    this.isReconnecting = false;
    this.reconnectAttempts = 0;

    if (this.ws) {
      try {
        this.ws.close({
          success: () => {
            console.log('[OmniWS] 连接已关闭');
          },
          fail: (err) => {
            console.error('[OmniWS] 关闭失败:', err);
          }
        });
      } catch (err) {
        console.error('[OmniWS] 关闭异常:', err);
      }
      this.ws = null;
    }

    this.isConnected = false;
    this.messageQueue = [];
  }

  /**
   * 获取连接状态
   * @returns {boolean} 是否已连接
   */
  getConnectionStatus() {
    return this.isConnected;
  }

  /**
   * 获取重连状态
   * @returns {Object} 重连状态信息
   */
  getReconnectStatus() {
    return {
      isReconnecting: this.isReconnecting,
      attempts: this.reconnectAttempts,
      maxAttempts: this.maxReconnectAttempts
    };
  }

  /**
   * 检查会话是否仍然活跃（未超时）
   * @returns {boolean} 会话是否活跃
   */
  isSessionActive() {
    if (!this.isConnected) {
      return false;
    }

    const timeSinceActivity = Date.now() - this.lastActivityTime;
    const isActive = timeSinceActivity < this.sessionTimeoutMs;

    if (!isActive) {
      console.warn(`[OmniWS] 会话已超时: ${Math.round(timeSinceActivity / 1000)}秒无活动`);
    }

    return isActive;
  }

  /**
   * 获取会话剩余时间（秒）
   * @returns {number} 剩余秒数，如果未连接返回0
   */
  getSessionTimeRemaining() {
    if (!this.isConnected || this.lastActivityTime === 0) {
      return 0;
    }

    const timeSinceActivity = Date.now() - this.lastActivityTime;
    const remaining = Math.max(0, Math.round((this.sessionTimeoutMs - timeSinceActivity) / 1000));

    return remaining;
  }

  /**
   * 如果会话超时则重新初始化
   * @returns {Promise<void>}
   */
  async reinitializeIfNeeded() {
    if (this.isSessionActive()) {
      console.log(`[OmniWS] 会话仍然活跃，剩余 ${this.getSessionTimeRemaining()} 秒`);
      return;
    }

    console.log('[OmniWS] 会话已超时，正在重新初始化...');

    wx.showLoading({
      title: '重新连接中...',
      mask: true
    });

    try {
      // 先关闭旧连接
      this.close();

      // 等待一小段时间确保连接完全关闭
      await new Promise(resolve => setTimeout(resolve, 500));

      // 重新连接
      await this.connect(this.dialectType, this.voice);

      wx.hideLoading();

      wx.showToast({
        title: '重新连接成功',
        icon: 'success',
        duration: 1500
      });

      console.log('[OmniWS] 会话重新初始化成功');
    } catch (err) {
      wx.hideLoading();

      wx.showToast({
        title: '重新连接失败',
        icon: 'none',
        duration: 2000
      });

      console.error('[OmniWS] 会话重新初始化失败:', err);
      throw err;
    }
  }
}

module.exports = OmniWebSocket;
