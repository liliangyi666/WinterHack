/**
 * PCM 音频格式转换工具
 *
 * 功能：
 * - 将 Base64 编码的 PCM 音频数据转换为 WAV 格式
 * - 添加 44 字节的 WAV 文件头
 * - 支持小程序音频播放
 *
 * @class PCMConverter
 * @date 2025-10-20
 */

class PCMConverter {
  /**
   * 构造函数
   */
  constructor() {
    console.log('[PCMConverter] PCM转WAV工具已初始化');
  }

  /**
   * 将 Base64 编码的 PCM 音频转换为 WAV 格式
   *
   * @param {string} pcmBase64 - Base64 编码的 PCM 数据
   * @param {number} sampleRate - 采样率（Hz），默认 24000（Qwen3-Omni 输出）
   * @param {number} channels - 声道数，默认 1（单声道）
   * @param {number} bitsPerSample - 位深度，默认 16（16bit）
   * @returns {string} Base64 编码的 WAV 数据
   *
   * @example
   * const converter = new PCMConverter();
   * const wavBase64 = converter.pcmToWav(pcmBase64, 24000);
   */
  pcmToWav(pcmBase64, sampleRate = 24000, channels = 1, bitsPerSample = 16) {
    try {
      if (!pcmBase64 || typeof pcmBase64 !== 'string') {
        throw new Error('无效的PCM数据：必须是Base64字符串');
      }

      console.log(`[PCMConverter] 开始转换: 采样率=${sampleRate}Hz, 声道=${channels}, 位深=${bitsPerSample}bit`);

      const pcmData = wx.base64ToArrayBuffer(pcmBase64);
      const pcmBytes = new Uint8Array(pcmData);
      const dataSize = pcmBytes.length;

      console.log(`[PCMConverter] PCM数据大小: ${dataSize} bytes`);

      if (dataSize === 0) {
        throw new Error('PCM数据为空');
      }

      const byteRate = sampleRate * channels * bitsPerSample / 8;
      const blockAlign = channels * bitsPerSample / 8;

      const wavHeader = this._createWavHeader(dataSize, sampleRate, channels, bitsPerSample, byteRate, blockAlign);

      const wavData = new Uint8Array(44 + dataSize);
      wavData.set(new Uint8Array(wavHeader), 0);
      wavData.set(pcmBytes, 44);

      const wavBase64 = wx.arrayBufferToBase64(wavData.buffer);

      console.log(`[PCMConverter] 转换完成: WAV数据大小=${wavData.length} bytes (包含44字节头)`);

      return wavBase64;

    } catch (err) {
      console.error('[PCMConverter] 转换失败:', err);
      throw err;
    }
  }

  /**
   * 创建 WAV 文件头（44 字节）
   *
   * WAV 格式结构：
   * - RIFF 头（12 字节）
   * - fmt 子块（24 字节）
   * - data 子块头（8 字节）
   *
   * @param {number} dataSize - PCM 数据大小（字节）
   * @param {number} sampleRate - 采样率
   * @param {number} channels - 声道数
   * @param {number} bitsPerSample - 位深度
   * @param {number} byteRate - 字节率
   * @param {number} blockAlign - 块对齐
   * @returns {ArrayBuffer} WAV 头部数据
   * @private
   */
  _createWavHeader(dataSize, sampleRate, channels, bitsPerSample, byteRate, blockAlign) {
    const header = new ArrayBuffer(44);
    const view = new DataView(header);

    this._writeString(view, 0, 'RIFF');
    view.setUint32(4, 36 + dataSize, true);
    this._writeString(view, 8, 'WAVE');

    this._writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, channels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, byteRate, true);
    view.setUint16(32, blockAlign, true);
    view.setUint16(34, bitsPerSample, true);

    this._writeString(view, 36, 'data');
    view.setUint32(40, dataSize, true);

    return header;
  }

  /**
   * 向 DataView 写入字符串
   *
   * @param {DataView} view - 目标 DataView
   * @param {number} offset - 写入偏移量
   * @param {string} string - 要写入的字符串
   * @private
   */
  _writeString(view, offset, string) {
    for (let i = 0; i < string.length; i++) {
      view.setUint8(offset + i, string.charCodeAt(i));
    }
  }

  /**
   * 验证 PCM 数据格式
   *
   * @param {string} pcmBase64 - Base64 编码的 PCM 数据
   * @returns {Object} 验证结果
   * @returns {boolean} returns.valid - 是否有效
   * @returns {string} returns.message - 验证消息
   */
  validatePCMData(pcmBase64) {
    try {
      if (!pcmBase64) {
        return { valid: false, message: 'PCM数据为空' };
      }

      if (typeof pcmBase64 !== 'string') {
        return { valid: false, message: 'PCM数据必须是字符串' };
      }

      if (pcmBase64.length === 0) {
        return { valid: false, message: 'PCM数据长度为0' };
      }

      const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
      if (!base64Regex.test(pcmBase64)) {
        return { valid: false, message: 'PCM数据不是有效的Base64格式' };
      }

      const pcmData = wx.base64ToArrayBuffer(pcmBase64);
      if (pcmData.byteLength === 0) {
        return { valid: false, message: '解码后的PCM数据为空' };
      }

      return { valid: true, message: 'PCM数据有效' };

    } catch (err) {
      return { valid: false, message: `验证失败: ${err.message}` };
    }
  }

  /**
   * 批量转换 PCM 数据为 WAV
   *
   * @param {Array<string>} pcmBase64Array - PCM Base64 数据数组
   * @param {number} sampleRate - 采样率
   * @returns {Array<string>} WAV Base64 数据数组
   */
  batchConvert(pcmBase64Array, sampleRate = 24000) {
    if (!Array.isArray(pcmBase64Array)) {
      throw new Error('输入必须是数组');
    }

    console.log(`[PCMConverter] 批量转换 ${pcmBase64Array.length} 个PCM数据`);

    const results = [];
    let successCount = 0;
    let failCount = 0;

    pcmBase64Array.forEach((pcmBase64, index) => {
      try {
        const wavBase64 = this.pcmToWav(pcmBase64, sampleRate);
        results.push(wavBase64);
        successCount++;
      } catch (err) {
        console.error(`[PCMConverter] 第 ${index + 1} 个数据转换失败:`, err);
        results.push(null);
        failCount++;
      }
    });

    console.log(`[PCMConverter] 批量转换完成: 成功=${successCount}, 失败=${failCount}`);

    return results;
  }

  /**
   * 获取 WAV 格式信息
   *
   * @param {number} sampleRate - 采样率
   * @param {number} channels - 声道数
   * @param {number} bitsPerSample - 位深度
   * @returns {Object} WAV 格式信息
   */
  getWavInfo(sampleRate = 24000, channels = 1, bitsPerSample = 16) {
    const byteRate = sampleRate * channels * bitsPerSample / 8;
    const blockAlign = channels * bitsPerSample / 8;

    return {
      format: 'WAV',
      sampleRate: sampleRate,
      channels: channels,
      bitsPerSample: bitsPerSample,
      byteRate: byteRate,
      blockAlign: blockAlign,
      headerSize: 44
    };
  }
}

module.exports = PCMConverter;
