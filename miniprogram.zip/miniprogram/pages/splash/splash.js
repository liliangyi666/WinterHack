Page({
  data: {
    // 可以在这里添加页面需要的数据
  },

  onLoad: function() {
    // 页面加载时的逻辑
    console.log('Splash page loaded');
  },

  // 点击页面跳转到原来的首页
  goToIndex: function() {
    wx.navigateTo({
      url: '/pages/index/index'
    });
  }
})