Page({
  goGame() {
    wx.navigateTo({ url: "/pages/game-entry/game-entry" })
  },

  goStory() {
    wx.navigateTo({ url: "/pages/story/story" })
  },

  goDialogue() {
    wx.navigateTo({ url: "/pages/dialogue/dialogue" })
  },

  // 跳转到成就中心页面
  goAchievement() {
    wx.navigateTo({ url: "/pages/achievement/achievement" })
  },

  data: {
    isRecording: false // 录音状态标记，默认未录制
  },

  /**
   * 切换录音状态
   * 点击按钮时触发，切换isRecording的值
   * 同时显示对应的提示信息
   */
  toggleRecord() {
    // 切换录音状态（取反）
    const newState = !this.data.isRecording;
    this.setData({
      isRecording: newState
    });

    // 根据新状态显示不同的提示信息
    const toastText = newState ? "正在录制..." : "已停止录制";
    wx.showToast({
      title: toastText,
      icon: "none", // 不显示图标，只显示文字
      duration: 1500 // 提示显示时间1.5秒
    });
  },

  // 页面卸载时清理资源
  onUnload() {
    // 清理完成
  }

})

