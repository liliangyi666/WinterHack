// pages/story/story.js
Page({
  data: {
    stories: [
      {
        id: 1,
        title: "四川方言故事：巴适的一天",
        description: "讲述了四川人一天的生活，充满了地道的方言表达，从早晨的茶馆到晚上的火锅。",
        dialect: "四川方言",
        cover: "https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p1.jpg",
        audio: "",
        duration: "05:23",
        author: "张大爷",
        listenCount: 1256,
        likeCount: 324,
        isLiked: false,
        category: "生活"
      },
      {
        id: 2,
        title: "方言笑话：瓜娃子进城",
        description: "一个搞笑的方言故事，讲述了农村娃第一次进城的有趣经历和闹的笑话。",
        dialect: "四川方言",
        cover: "https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p2.jpg",
        audio: "",
        duration: "04:15",
        author: "李二姐",
        listenCount: 987,
        likeCount: 256,
        isLiked: false,
        category: "笑话"
      },
      {
        id: 3,
        title: "传统故事：蜀地传说",
        description: "用四川方言讲述的古老传说，充满了地方特色和神秘色彩。",
        dialect: "四川方言",
        cover: "https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p3.jpg",
        audio: "",
        duration: "07:30",
        author: "王老师",
        listenCount: 1567,
        likeCount: 412,
        isLiked: false,
        category: "传说"
      },
      {
        id: 4,
        title: "现代故事：成都的夜晚",
        description: "用方言描绘现代成都的夜生活，展现城市的另一面和年轻人的生活状态。",
        dialect: "四川方言",
        cover: "https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p4.png",
        audio: "",
        duration: "06:45",
        author: "小陈",
        listenCount: 876,
        likeCount: 210,
        isLiked: false,
        category: "生活"
      },
      {
        id: 5,
        title: "端午习俗：高邮咸鸭蛋的故事",
        description: "用江苏方言讲述端午吃鸭蛋的传统习俗，以及高邮咸鸭蛋的独特风味和制作工艺。",
        dialect: "江苏方言",
        cover: "https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/%E7%AB%AF%E5%8D%88%E7%9A%84%E9%B8%AD%E8%9B%8B.png",
        audio: "",
        duration: "05:48",
        author: "鸭蛋张",
        listenCount: 1024,
        likeCount: 289,
        isLiked: false,
        category: "生活"
      },
      {
        id: 6,
        title: "民间技艺：河南打铁花的传奇",
        description: "用河南方言讲述这项古老而壮观的民间艺术，铁水飞溅如流星般绚烂的背后故事。",
        dialect: "河南方言",
        cover: "https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/%E6%B2%B3%E5%8D%97%E6%89%93%E9%93%81%E8%8A%B1.png",
        audio: "",
        duration: "06:32",
        author: "铁花李",
        listenCount: 1456,
        likeCount: 367,
        isLiked: false,
        category: "传说"
      },
      {
        id: 7,
        title: "城市风光：长沙橘子洲烟花",
        description: "用湖南方言讲述长沙橘子洲头烟花表演的由来、发展和观看体验，感受湘江两岸的热闹氛围。",
        dialect: "湖南方言",
        cover: "https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/%E6%A9%98%E5%AD%90%E6%B4%B2%E7%83%9F%E8%8A%B1.jpg",
        audio: "",
        duration: "05:15",
        author: "湘江王",
        listenCount: 1189,
        likeCount: 312,
        isLiked: false,
        category: "生活"
      },
      {
        id: 8,
        title: "地方传说：湘西赶尸的神秘面纱",
        description: "用湘西土话讲述湘西赶尸这一神秘习俗的历史渊源、文化背景和现代解读，揭开神秘传说的面纱。",
        dialect: "湖南湘西土话",
        cover: "https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/%E6%B9%98%E8%A5%BF%E8%B5%B6%E5%B0%B8.jpg",
        audio: "",
        duration: "07:20",
        author: "苗家阿婆",
        listenCount: 1876,
        likeCount: 498,
        isLiked: false,
        category: "传说"
      }
    ],
    categories: [
      { id: 'all', name: '中国', icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/%E4%B8%AD%E5%9B%BD.png' },
      { id: '四川', name: '四川', icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/%E5%9B%9B%E5%B7%9D.png' },
      { id: '湖南', name: '湖南', icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/%E6%B9%96%E5%8D%97.png' },
      { id: '河南', name: '河南', icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/%E6%B2%B3%E5%8D%97.png' },
      { id: '江西', name: '江西', icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/%E6%B1%9F%E8%A5%BF.png' }
    ],
    selectedCategory: 'all',
    filteredStories: [],
    featuredStory: null,
    isPlaying: null,
    progress: 0,
    currentTime: '00:00',
    miniPlayerVisible: false,
    currentStory: null,
    audioContext: null
  },

  onLoad() {
    // 初始化过滤后的故事列表
    this.setData({
      filteredStories: this.data.stories
    });
    
    // 随机选择一个精选故事
    const randomIndex = Math.floor(Math.random() * this.data.stories.length);
    const featuredStory = { ...this.data.stories[randomIndex], index: randomIndex };
    this.setData({
      featuredStory: featuredStory
    });
    
    // 创建音频上下文（实际项目中使用）
    // this.setData({
    //   audioContext: wx.createInnerAudioContext()
    // });
  },

  // 选择分类
  selectCategory(e) {
    const categoryId = e.currentTarget.dataset.id;
    
    let filteredStories;
    if (categoryId === 'all') {
      filteredStories = this.data.stories;
    } else {
      // 根据故事的方言包含省份名称来筛选
      filteredStories = this.data.stories.filter(story => story.dialect.includes(categoryId));
    }
    
    this.setData({
      selectedCategory: categoryId,
      filteredStories: filteredStories
    });
  },

  // 播放/暂停音频
  playAudio(e) {
    const index = e.currentTarget.dataset.index;
    const story = this.data.stories[index];
    
    // 如果点击的是当前播放的故事，则暂停
    if (this.data.isPlaying === index) {
      this.pauseAudio();
    } else {
      // 停止之前的播放
      this.stopAudio();
      
      // 开始新的播放
      this.setData({
        isPlaying: index,
        progress: 0,
        currentTime: '00:00',
        miniPlayerVisible: true,
        currentStory: story
      });
      
      // 模拟音频播放
      this.startProgressSimulation();
      
      wx.showToast({
        title: `正在播放: ${story.title}`,
        icon: 'none'
      });
    }
  },

  // 暂停音频
  pauseAudio() {
    this.setData({
      isPlaying: null
    });
    
    // 停止进度模拟
    if (this.progressInterval) {
      clearInterval(this.progressInterval);
      this.progressInterval = null;
    }
  },

  // 停止音频
  stopAudio() {
    this.setData({
      isPlaying: null,
      progress: 0,
      currentTime: '00:00'
    });
    
    // 停止进度模拟
    if (this.progressInterval) {
      clearInterval(this.progressInterval);
      this.progressInterval = null;
    }
  },

  // 切换播放状态（用于迷你播放器）
  togglePlayback() {
    if (this.data.isPlaying !== null) {
      this.pauseAudio();
    } else if (this.data.currentStory) {
      const index = this.data.stories.findIndex(s => s.id === this.data.currentStory.id);
      this.playAudio({ currentTarget: { dataset: { index } } });
    }
  },

  // 关闭迷你播放器
  closeMiniPlayer() {
    this.stopAudio();
    this.setData({
      miniPlayerVisible: false,
      currentStory: null
    });
  },

  // 模拟进度更新
  startProgressSimulation() {
    let seconds = 0;
    const totalSeconds = this.convertTimeToSeconds(this.data.stories[this.data.isPlaying].duration);
    
    this.progressInterval = setInterval(() => {
      seconds++;
      const progress = Math.min((seconds / totalSeconds) * 100, 100);
      const currentTime = this.convertSecondsToTime(seconds);
      
      this.setData({
        progress: progress,
        currentTime: currentTime
      });
      
      // 播放结束
      if (seconds >= totalSeconds) {
        this.stopAudio();
        
        // 自动播放下一个
        const nextIndex = (this.data.isPlaying + 1) % this.data.filteredStories.length;
        const actualIndex = this.data.stories.findIndex(s => s.id === this.data.filteredStories[nextIndex].id);
        
        setTimeout(() => {
          this.playAudio({ currentTarget: { dataset: { index: actualIndex } } });
        }, 1000);
      }
    }, 1000);
  },

  // 时间转换函数
  convertTimeToSeconds(timeStr) {
    const [minutes, seconds] = timeStr.split(':').map(Number);
    return minutes * 60 + seconds;
  },

  convertSecondsToTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  },

  // 切换喜欢状态
  toggleLike(e) {
    const index = e.currentTarget.dataset.index;
    const stories = [...this.data.stories];
    
    stories[index].isLiked = !stories[index].isLiked;
    if (stories[index].isLiked) {
      stories[index].likeCount++;
    } else {
      stories[index].likeCount--;
    }
    
    // 更新精选故事（如果是同一个）
    let featuredStory = this.data.featuredStory;
    if (featuredStory && featuredStory.id === stories[index].id) {
      featuredStory = { ...stories[index], index: index };
    }
    
    // 更新当前播放的故事
    let currentStory = this.data.currentStory;
    if (currentStory && currentStory.id === stories[index].id) {
      currentStory = { ...stories[index] };
    }
    
    this.setData({
      stories: stories,
      featuredStory: featuredStory,
      currentStory: currentStory,
      filteredStories: this.data.selectedCategory === 'all' ? stories : stories.filter(s => s.category === this.data.selectedCategory)
    });
    
    wx.showToast({
      title: stories[index].isLiked ? '喜欢成功' : '已取消喜欢',
      icon: 'none'
    });
  },

  // 生命周期函数：页面卸载时停止所有播放
  onUnload() {
    this.stopAudio();
  },

  // 生命周期函数：页面隐藏时关闭迷你播放器
  onHide() {
    if (this.data.miniPlayerVisible) {
      this.setData({
        miniPlayerVisible: false
      });
    }
  },

  // 生命周期函数：页面显示时恢复迷你播放器
  onShow() {
    if (this.data.isPlaying !== null) {
      this.setData({
        miniPlayerVisible: true
      });
    }
  }
})