Page({
  data: {
    messages: [],
    inputValue: '',
    isRecording: false,
    dialectType: '普通话',
    dialectTypes: ['普通话', '四川话', '广东话', '上海话', '闽南语', '北京话', '南京话', '陕西话', '天津话'],
    isTranslating: false,
    showVirtualHumanSpeech: true,
    virtualHumanMessage: '欢迎来到方言对话！我是你的方言学习助手，请问有什么可以帮你的吗？',
    currentAvatar: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/%E5%B0%81%E9%9D%A2.gif',
    isAnimating: false,
    isConnected: false,
    aiResponding: false,
    currentPlayingId: null,
    userRecordingStartTime: 0,
    currentAIAudioPath: null,
    currentAIMessageId: null,    // 当前正在构建的AI消息ID
    currentAIText: '',            // 累积的AI文本
    currentAIAudioChunks: []      // 累积的AI音频块
  },

  async onLoad() {
    this.initAudioContext();

    this.initWelcomeMessages();

    this.startPageAnimation();

    // 异步初始化 Omni 连接
    await this._initOmni();
  },
  
  // 页面进入动画
  startPageAnimation() {
    this.setData({ isAnimating: true });
    setTimeout(() => {
      this.setData({ isAnimating: false });
    }, 800);
  },
  
  // 初始化欢迎消息
  initWelcomeMessages() {
    // 只显示欢迎消息，不再添加模拟对话
    this.addMessage('system', '欢迎来到方言对话！我是你的方言学习助手，连接成功后就可以开始对话了。', true);
  },

  // 初始化音频上下文
  initAudioContext() {
    this.innerAudioContext = wx.createInnerAudioContext();
  },

  async _initOmni() {
    console.log('[Dialogue] 初始化Qwen3-Omni连接');

    const currentDialect = this.data.dialectType || '四川话';

    console.log(`[Dialogue] 方言: ${currentDialect}`);

    try {
      // 使用全局单例连接
      const app = getApp();
      const { omniWS, audioManager } = await app.getOmniConnection(currentDialect);

      this.omniWS = omniWS;
      this.audioManager = audioManager;

    this.omniWS.onInitialized = () => {
      console.log('[Dialogue] Omni连接初始化成功');
      this.setData({ isConnected: true });

      wx.showToast({
        title: '语音服务已连接',
        icon: 'success',
        duration: 2000
      });
    };

    this.omniWS.onUserText = (text) => {
      console.log('[Dialogue] 用户文本:', text);
      // 用户语音识别完成，更新已有的用户消息
      const messages = this.data.messages;
      const lastUserMsg = messages.filter(m => m.sender === 'user').pop();
      if (lastUserMsg && lastUserMsg.type === 'audio') {
        lastUserMsg.recognizedText = text;
        this.setData({ messages });
      }
    };

    this.omniWS.onAIText = (textDelta) => {
      console.log('[Dialogue] AI文本增量:', textDelta);

      // 累积AI文本
      const currentText = this.data.currentAIText + textDelta;
      this.setData({ currentAIText: currentText });

      // 如果还没有AI消息，创建一个语音消息气泡
      if (!this.data.currentAIMessageId) {
        const messages = this.data.messages;
        const newMessage = {
          id: messages.length + 1,
          sender: 'system',
          type: 'audio',  // 改为音频类型
          content: '语音回复中...',  // 临时内容
          recognizedText: currentText,  // 识别的文本
          time: new Date().toLocaleTimeString(),
          isDialect: true,
          isPlaying: false,
          duration: 0  // 临时时长
        };
        messages.push(newMessage);
        this.setData({
          messages,
          currentAIMessageId: newMessage.id,
          aiResponding: true
        });
        this.scrollToBottom();
      } else {
        // 更新现有AI消息的文本
        const messages = this.data.messages;
        const aiMsg = messages.find(m => m.id === this.data.currentAIMessageId);
        if (aiMsg) {
          aiMsg.recognizedText = currentText;
          this.setData({ messages });
        }
      }
    };

    this.omniWS.onAIAudio = (audioBase64) => {
      console.log('[Dialogue] 收到AI音频块');
      // 累积音频块
      const chunks = this.data.currentAIAudioChunks;
      chunks.push(audioBase64);
      this.setData({ currentAIAudioChunks: chunks });

      // 同时添加到播放队列（实时播放）
      this.audioManager.addAudioChunk(audioBase64);
    };

    this.omniWS.onResponseDone = () => {
      console.log('[Dialogue] AI响应完成');
      this.setData({ aiResponding: false });

      // 更新AI消息状态
      const messages = this.data.messages;
      const aiMsg = messages.find(m => m.id === this.data.currentAIMessageId);
      if (aiMsg) {
        // 估算音频时长（假设24kHz采样率，16bit，单声道）
        const totalAudioSize = this.data.currentAIAudioChunks.reduce((sum, chunk) => sum + chunk.length, 0);
        const estimatedDuration = Math.ceil(totalAudioSize / 32000);  // 粗略估算

        aiMsg.content = `语音 ${estimatedDuration}"`;
        aiMsg.duration = estimatedDuration;
        aiMsg.hasAudio = true;

        // 保存音频块引用（用于重播）
        aiMsg.audioChunks = [...this.data.currentAIAudioChunks];

        this.setData({ messages });
      }

      // 重置累积状态
      this.setData({
        currentAIMessageId: null,
        currentAIText: '',
        currentAIAudioChunks: []
      });
    };

    this.omniWS.onError = (error) => {
      console.error('[Dialogue] WebSocket错误:', error);
      this.setData({ isConnected: false });
    };

    this.omniWS.onClose = () => {
      console.log('[Dialogue] WebSocket连接关闭');
      this.setData({ isConnected: false });
    };

    // 设置录音完成回调
    this.audioManager.onRecordingComplete = (recordInfo) => {
      console.log('[Dialogue] 录音完成:', recordInfo);

      const duration = recordInfo.duration || 0;
      this.addMessage('user', {
        type: 'audio',
        content: `语音 ${duration}"`,
        audioPath: recordInfo.tempFilePath,
        duration: duration
      });
    };

    // 如果已经连接，设置状态
    if (this.omniWS.isConnected) {
      this.setData({ isConnected: true });
      wx.showToast({
        title: '语音服务已连接',
        icon: 'success',
        duration: 2000
      });
    }

    } catch (err) {
      console.error('[Dialogue] 初始化Omni失败:', err);

      // 确保显示详细错误信息
      const errorMsg = err.message || err.errMsg || '未知错误';
      console.error('[Dialogue] 错误详情:', errorMsg);

      this.addMessage('system', `语音服务连接失败：${errorMsg}。请检查网络连接后重试。`, true);

      wx.showToast({
        title: '语音服务连接失败',
        icon: 'none',
        duration: 3000
      });

      // 设置连接状态为未连接
      this.setData({ isConnected: false });
    }
  },

  // 添加消息到聊天记录
  // options: { type: 'text'|'audio', content, audioPath, duration, isDialect }
  addMessage(sender, contentOrOptions, isDialect = false) {
    const messages = this.data.messages;

    let message = {
      id: messages.length + 1,
      sender: sender,
      time: new Date().toLocaleTimeString(),
      isPlaying: false
    };

    if (typeof contentOrOptions === 'object') {
      message = { ...message, ...contentOrOptions };
    } else {
      message.type = 'text';
      message.content = contentOrOptions;
      message.isDialect = isDialect;
    }

    messages.push(message);
    this.setData({ messages });

    if (sender === 'system' && message.content) {
      this.setData({
        showVirtualHumanSpeech: true,
        virtualHumanMessage: message.content
      });
    }

    this.scrollToBottom();
  },

  // 滚动到底部
  scrollToBottom() {
    setTimeout(() => {
      const query = wx.createSelectorQuery();
      query.select('.chat-messages').boundingClientRect();
      query.selectViewport().scrollOffset();
      query.exec((res) => {
        res[1].scrollTop = res[0].bottom;
      });
    }, 100);
  },

  // 输入框内容变化
  onInput(e) {
    this.setData({
      inputValue: e.detail.value
    });
  },

  // 发送消息
  sendMessage() {
    const { inputValue } = this.data;
    
    // 增强的输入验证
    if (!inputValue || !inputValue.trim()) {
      wx.showToast({
        title: '请输入消息内容',
        icon: 'none'
      });
      return;
    }

    try {
      // 添加用户消息
      this.addMessage('user', inputValue);
      
      // 清空输入框
      this.setData({ inputValue: '' });

      // 模拟系统回复
      this.simulateSystemReply(inputValue);
    } catch (error) {
      console.error('发送消息失败:', error);
      wx.showToast({
        title: '发送失败，请重试',
        icon: 'none'
      });
    }
  },


  // 模拟系统回复 - 增强版，支持更多对话场景
  simulateSystemReply(userInput) {
    // 扩展的回复逻辑，提供更丰富的对话体验
    let replies = {
      '你好': '你好呀！很高兴和你用方言交流～今天想学哪种方言呢？',
      '谢谢': '不用谢，有什么问题随时问我！学习方言很有趣吧？',
      '再见': '再见啦，下次再一起学方言！记得多练习哦～',
      '你会说什么方言': '我会说四川话、广东话、上海话、闽南语和东北话，你想听哪种呢？',
      '教我一句方言': this.getDialectExample(),
      '今天天气怎么样': `今天天气应该不错！用${this.data.dialectType}说"天气"就是"${this.getDialectWord('天气')}"`,
      '四川话': '四川话很有趣的！四川人爱说"巴适"表示舒服，"安逸"表示好，"瓜娃子"有时候是亲昵的称呼哦～',
      '广东话': '广东话又叫粤语，是中国方言里很有特色的一种。广东人常用"点样"表示怎么样，"食饭"表示吃饭，"饮咗茶未"是问喝了茶没有。',
      '上海话': '上海话软软糯糯的很好听！上海人说"阿拉"是我们，"侬"是你，"白相"是玩，"交关"是很、非常的意思。',
      '闽南语': '闽南语在福建和台湾很流行！"吃饭"叫"食饭"，"睡觉"叫"困"，"你好"是"恁好"，"谢谢"是"感谢"。',
      '东北话': '东北话直率又幽默！东北人常说"贼拉好"是特别好，"唠嗑"是聊天，"杠杠的"是非常好，"得劲"是舒服。',
      '怎么学习方言': '学习方言最好的方法是多听多说！可以通过听歌、看本地电视剧、和当地人交流来练习。我也可以教你一些基础词汇哦～',
      '方言有什么用': '方言是我们传统文化的重要组成部分，它承载着地方的历史、文化和情感。学习方言可以更好地了解不同地区的风土人情，也能增进人与人之间的亲切感。'
    };

    // 智能匹配回复，不区分大小写和标点符号
    const normalizedInput = userInput.replace(/[^一-龥a-zA-Z0-9]/g, '').toLowerCase();
    let reply = replies[userInput] || 
                Object.keys(replies).find(key => key.replace(/[^一-龥a-zA-Z0-9]/g, '').toLowerCase() === normalizedInput)?.value ||
                `我现在还不太明白"${userInput}"是什么意思，不过我会努力学习的！用${this.data.dialectType}说可能是"${userInput}${Math.random() > 0.5 ? '嘞' : '哒'}"`;
    
    // 显示正在输入状态
    this.setData({ isTranslating: true });
    
    // 延迟回复，模拟思考和翻译过程（根据回复长度调整延迟时间）
    const delayTime = 1000 + Math.min(reply.length * 5, 2000);
    setTimeout(() => {
      this.setData({ isTranslating: false });
      this.addMessage('system', reply, true);
    }, delayTime);
  },

  // 获取方言示例句子
  getDialectExample() {
    const dialectExamples = {
      '四川话': '今天教你一句四川话："巴适得板"，意思是很舒服、很好！',
      '广东话': '今天教你一句广东话："好犀利"，意思是很厉害！',
      '上海话': '今天教你一句上海话："老好额"，意思是很好！',
      '闽南语': '今天教你一句闽南语："真好势"，意思是很好、很顺利！',
      '东北话': '今天教你一句东北话："贼毙了"，意思是非常好、太棒了！'
    };
    return dialectExamples[this.data.dialectType] || '今天我们来学一句有趣的方言吧！';
  },

  // 获取方言词汇 - 扩展更多常用词汇
  getDialectWord(word) {
    const dialectWords = {
      '四川话': {
        '天气': '天气',
        '你好': '你好',
        '谢谢': '谢谢',
        '吃饭': '吃饭',
        '睡觉': '睡觉',
        '漂亮': '巴适',
        '好': '安逸',
        '朋友': '兄弟',
        '今天': '今儿',
        '明天': '明儿'
      },
      '广东话': {
        '天气': '天气',
        '你好': '你好',
        '谢谢': '多谢',
        '吃饭': '食饭',
        '睡觉': '瞓觉',
        '漂亮': '靓',
        '好': '好',
        '朋友': '朋友',
        '今天': '今日',
        '明天': '听日'
      },
      '上海话': {
        '天气': '天气',
        '你好': '侬好',
        '谢谢': '谢谢',
        '吃饭': '吃饭',
        '睡觉': '睏觉',
        '漂亮': '漂亮',
        '好': '好',
        '朋友': '朋友',
        '今天': '今朝',
        '明天': '明朝'
      },
      '闽南语': {
        '天气': '天气',
        '你好': '恁好',
        '谢谢': '感谢',
        '吃饭': '食饭',
        '睡觉': '困',
        '漂亮': '水',
        '好': '好',
        '朋友': '朋友',
        '今天': '今日',
        '明天': '明日'
      },
      '东北话': {
        '天气': '天儿',
        '你好': '你好',
        '谢谢': '谢谢',
        '吃饭': '吃饭',
        '睡觉': '睡觉',
        '漂亮': '带劲',
        '好': '贼拉好',
        '朋友': '哥们儿',
        '今天': '今儿个',
        '明天': '明儿个'
      }
    };
    return dialectWords[this.data.dialectType]?.[word] || word;
  },

  // 切换录音状态
  toggleRecord() {
    if (!this.audioManager) {
      // 尝试重新初始化
      wx.showModal({
        title: '语音服务未初始化',
        content: '语音服务可能连接失败，是否重新连接？',
        success: (res) => {
          if (res.confirm) {
            this._initOmni().then(() => {
              wx.showToast({
                title: '重新连接成功',
                icon: 'success',
                duration: 2000
              });
            }).catch(err => {
              console.error('[Dialogue] 重新初始化失败:', err);
            });
          }
        }
      });
      return;
    }

    if (!this.data.isConnected) {
      wx.showToast({
        title: '语音服务未连接',
        icon: 'none',
        duration: 2000
      });
      return;
    }

    const newState = !this.data.isRecording;
    this.setData({ isRecording: newState });

    if (newState) {
      console.log('[Dialogue] 开始录音');
      this.setData({ aiResponding: false });

      // 在开始录音前检查会话是否超时，如果超时则自动重连
      this.omniWS.reinitializeIfNeeded().then(() => {
        // 会话正常或重连成功后，开始录音
        this.audioManager.startRecording({
          format: 'pcm',
          sampleRate: 16000,
          numberOfChannels: 1,
          frameSize: 1
        });

        wx.showToast({
          title: '正在录音...',
          icon: 'none',
          duration: 1500
        });
      }).catch(err => {
        // 重连失败，取消录音
        console.error('[Dialogue] 会话重连失败，无法开始录音:', err);
        this.setData({ isRecording: false });
      });
    } else {
      console.log('[Dialogue] 停止录音');
      this.audioManager.stopRecording();

      this.setData({ aiResponding: true });

      wx.showToast({
        title: '录音已停止',
        icon: 'success',
        duration: 1500
      });
    }
  },

  // 切换方言类型
  async selectDialect(e) {
    const newDialect = e.currentTarget.dataset.dialect;
    const { dialectType } = this.data;

    // 如果点击的是当前方言，不做任何操作
    if (newDialect === dialectType) {
      console.log('[Dialogue] 已经是当前方言，无需切换');
      return;
    }

    // 更新方言类型
    this.setData({
      dialectType: newDialect,
      isConnected: false
    });

    // 显示切换提示
    wx.showLoading({
      title: `正在切换到${newDialect}...`,
      mask: true
    });

    try {
      // 清理旧连接
      console.log('[Dialogue] 切换方言，清理旧连接');
      const app = getApp();
      app.cleanupOmniConnection();

      // 等待一小段时间确保清理完成
      await new Promise(resolve => setTimeout(resolve, 500));

      // 使用新方言重新初始化连接
      console.log(`[Dialogue] 使用新方言初始化: ${newDialect}`);
      await this._initOmni();

      wx.hideLoading();

      // 显示切换成功消息
      this.addMessage('system', `已切换到${newDialect}，现在我将用${newDialect}和你对话！`, true);

      wx.showToast({
        title: `已切换到${newDialect}`,
        icon: 'success',
        duration: 2000
      });

    } catch (err) {
      wx.hideLoading();
      console.error('[Dialogue] 方言切换失败:', err);

      this.addMessage('system', `方言切换失败，请重试`, true);

      wx.showToast({
        title: '切换失败，请重试',
        icon: 'error',
        duration: 2000
      });
    }
  },

  // 播放语音消息
  playAudioMessage(e) {
    const { id } = e.currentTarget.dataset;
    const messages = this.data.messages;
    const message = messages.find(m => m.id === id);

    if (!message) {
      console.error('[Dialogue] 未找到语音消息');
      return;
    }

    // 检查是否正在播放同一条消息（暂停）
    if (this.data.currentPlayingId === id) {
      console.log('[Dialogue] 暂停播放');
      if (message.sender === 'user' && this.innerAudioContext) {
        this.innerAudioContext.pause();
      } else if (message.sender === 'system') {
        this.audioManager.pausePlaying();
      }
      message.isPlaying = false;
      this.setData({
        messages,
        currentPlayingId: null
      });
      return;
    }

    // 停止之前的播放
    if (this.data.currentPlayingId !== null) {
      const prevMessage = messages.find(m => m.id === this.data.currentPlayingId);
      if (prevMessage) {
        prevMessage.isPlaying = false;
      }
      if (this.innerAudioContext) {
        this.innerAudioContext.stop();
      }
      this.audioManager.stopPlaying();
    }

    // 开始播放
    message.isPlaying = true;
    this.setData({
      messages,
      currentPlayingId: id
    });

    // 判断是用户录音还是AI回复
    if (message.sender === 'user' && message.audioPath) {
      // 用户录音：直接播放文件
      console.log('[Dialogue] 播放用户录音:', message.audioPath);

      if (!this.innerAudioContext) {
        this.innerAudioContext = wx.createInnerAudioContext();
      }

      this.innerAudioContext.src = message.audioPath;

      this.innerAudioContext.onEnded(() => {
        console.log('[Dialogue] 播放完成');
        message.isPlaying = false;
        this.setData({
          messages,
          currentPlayingId: null
        });
      });

      this.innerAudioContext.onError((err) => {
        console.error('[Dialogue] 播放失败:', err);
        message.isPlaying = false;
        this.setData({
          messages,
          currentPlayingId: null
        });

        wx.showToast({
          title: '播放失败',
          icon: 'none',
          duration: 2000
        });
      });

      this.innerAudioContext.play();

    } else if (message.sender === 'system' && message.audioChunks && message.audioChunks.length > 0) {
      // AI回复：播放音频块
      console.log('[Dialogue] 重播AI音频，音频块数量:', message.audioChunks.length);

      // 停止当前播放并清空队列
      this.audioManager.stopPlaying();

      // 等待一小段时间确保停止操作完成，然后重新播放
      setTimeout(() => {
        console.log('[Dialogue] 开始重播，依次添加音频块');

        // 使用递归方式依次添加音频块，确保每块都能正常播放
        let index = 0;
        const addNextChunk = () => {
          if (index < message.audioChunks.length) {
            const chunk = message.audioChunks[index];
            console.log(`[Dialogue] 添加音频块 ${index + 1}/${message.audioChunks.length}`);
            this.audioManager.addAudioChunk(chunk);
            index++;

            // 延迟100ms后添加下一块，给第一块足够时间开始播放
            if (index < message.audioChunks.length) {
              setTimeout(addNextChunk, 100);
            } else {
              console.log('[Dialogue] 所有音频块已添加完成');
            }
          }
        };

        // 开始添加第一块
        addNextChunk();

        // 监听播放结束
        const estimatedDuration = (message.duration || 5) * 1000;

        // 清除之前的定时器（如果存在）
        if (this.replayTimer) {
          clearTimeout(this.replayTimer);
        }

        // 设置新的定时器
        this.replayTimer = setTimeout(() => {
          console.log('[Dialogue] AI音频播放完成（预估时间）');
          message.isPlaying = false;
          this.setData({
            messages,
            currentPlayingId: null
          });
          this.replayTimer = null;
        }, estimatedDuration);

      }, 300);  // 延迟300ms确保停止操作完成

    } else {
      console.error('[Dialogue] 无可播放的音频');
      message.isPlaying = false;
      this.setData({
        messages,
        currentPlayingId: null
      });

      wx.showToast({
        title: '无音频数据',
        icon: 'none',
        duration: 2000
      });
    }
  },

  // 播放方言
  playDialect(e) {
    const { content } = e.currentTarget.dataset;
    wx.showToast({
      title: '正在播放方言...',
      icon: 'none',
      duration: 1000
    });
    // 实际项目中应该调用语音合成API播放方言
  },

  // 页面卸载时清理资源
  onUnload() {
    console.log('[Dialogue] 页面卸载，清理本地资源');

    // 停止录音和播放
    if (this.audioManager) {
      this.audioManager.stopRecording();
      this.audioManager.stopPlaying();
    }

    // 清理重播定时器
    if (this.replayTimer) {
      clearTimeout(this.replayTimer);
      this.replayTimer = null;
    }

    // 只清理页面本地的音频上下文
    if (this.innerAudioContext) {
      this.innerAudioContext.destroy();
      this.innerAudioContext = null;
    }

    // 不关闭全局 WebSocket 连接和 AudioManager
    // 它们由 app.js 管理，在小程序退出时才清理
    this.omniWS = null;
    this.audioManager = null;

    console.log('[Dialogue] 页面资源清理完成（全局连接保留）');
  },

  // 分享给朋友
  onShareAppMessage() {
    return {
      title: '方言对话 - 学习中国各地方言',
      path: '/pages/dialogue/dialogue',
      imageUrl: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p1.jpg'
    };
  },

  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: '方言对话 - 学习中国各地方言',
      query: 'dialectType=' + this.data.dialectType,
      imageUrl: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p1.jpg'
    };
  }
});