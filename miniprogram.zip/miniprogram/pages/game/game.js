const OmniAudioManager = require('../../utils/omni-audio.js');

Page({
  data: {
    gameMode: 'quiz', // quiz: 知识问答, speech: 发音测评
    questions: [
      {
        question: "四川方言中'巴适'是什么意思?",
        options: ['舒适，不错', '很巴适'],
        correct: 0,
        explanation: "'巴适'是四川方言中非常常用的词汇，用来形容事物舒适、令人满意的状态。"
      },
      {
        question: "四川方言中'瓜娃子'是什么意思?",
        options: ['瓜的娃娃', '傻瓜，笨'],
        correct: 1,
        explanation: "'瓜娃子'是一种亲昵的调侃称呼，通常用来形容人有点傻气或者做事不机灵。"
      },
      {
        question: "四川方言中'打牙祭'是什么意思?",
        options: ['祭祀活动', '改善伙食'],
        correct: 1,
        explanation: "'打牙祭'原指旧时祭祀后分食供品，现在泛指平时吃得简单，偶尔吃顿好的改善生活。"
      },
      {
        question: "四川方言中'刹角'是什么意思?",
        options: ['结束', '刹车'],
        correct: 0,
        explanation: "'刹角'在四川方言中表示事情结束、完成的意思，类似于'收尾'。"
      },
      {
        question: "四川方言中'装疯迷窍'是什么意思?",
        options: ['假装发疯', '真的疯了'],
        correct: 0,
        explanation: "'装疯迷窍'指故意装出疯癫的样子，通常用于形容人无理取闹或撒娇。"
      },
      {
        question: "四川方言中'梭边边'是什么意思?",
        options: ['梭子', '躲躲闪闪'],
        correct: 1,
        explanation: "'梭边边'形象地描述了人遇到问题或责任时，像织布梭子一样往边上躲的行为。"
      },
      {
        question: "四川方言中'闷墩儿'是什么意思?",
        options: ['结实，笨', '闷罐'],
        correct: 0,
        explanation: "'闷墩儿'既可以形容人性格内向、不善言辞，也可以指人憨厚老实。"
      },
      {
        question: "四川方言中'抵拢倒拐'是什么意思?",
        options: ['一直走到头再转弯', '抵住拐子'],
        correct: 0,
        explanation: "'抵拢倒拐'是典型的四川方言方位指引，意思是一直走到路的尽头，然后转弯。"
      },
      {
        question: "四川方言中'拉稀摆带'是什么意思?",
        options: ['拉肚子', '拖泥带水'],
        correct: 1,
        explanation: "'拉稀摆带'用来形容人做事犹豫不决、拖泥带水，不够干脆利落。"
      },
      {
        question: "四川方言中'雄起'是什么意思?",
        options: ['加油，振作', '雄伟起来'],
        correct: 0,
        explanation: "'雄起'是四川方言中极具代表性的鼓励词汇，意思是加油、振作起来，常用于为他人打气。"
      }
    ],
    currentIndex: 0,
    result: '',
    answered: false,
    showNextButton: false,
    gameCompleted: false,
    selectedIndex: -1,
    isCorrect: false,
    score: 0,
    correctCount: 0,
    incorrectCount: 0,
    currentExplanation: '',
    showExplanation: false,
    accuracy: 0,
    ranking: 0,
    medalImage: '',
    medalText: ''
  },
  // 发音测评题目
  speechQuestions: [
    {
      phrase: '巴适得板',
      dialectType: '四川话',
      standardPronunciation: 'bā shì dé bǎn',
      description: '表示非常舒适、满意的状态'
    },
    {
      phrase: '瓜娃子',
      dialectType: '四川话',
      standardPronunciation: 'guā wá zi',
      description: '亲昵的调侃称呼，形容人有点傻气'
    },
    {
      phrase: '雄起',
      dialectType: '四川话',
      standardPronunciation: 'xióng qǐ',
      description: '加油、振作起来的意思'
    },
    {
      phrase: '打牙祭',
      dialectType: '四川话',
      standardPronunciation: 'dǎ yá jì',
      description: '改善伙食，吃顿好的'
    },
    {
      phrase: '抵拢倒拐',
      dialectType: '四川话',
      standardPronunciation: 'dǐ lǒng dào guǎi',
      description: '走到头再转弯的意思'
    }
  ],

  // 答题处理
  answerQuestion(e) {
    const { index } = e.currentTarget.dataset;
    const { questions, currentIndex, score } = this.data;
    const isCorrect = index === questions[currentIndex].correct;
    const newScore = isCorrect ? score + 10 : score;
    const newCorrectCount = isCorrect ? this.data.correctCount + 1 : this.data.correctCount;
    const newIncorrectCount = !isCorrect ? this.data.incorrectCount + 1 : this.data.incorrectCount;
    
    this.setData({
      result: isCorrect ? '✅ 回答正确!' : '❌ 回答错误!',
      answered: true,
      showNextButton: true,
      selectedIndex: index,
      isCorrect: isCorrect,
      score: newScore,
      correctCount: newCorrectCount,
      incorrectCount: newIncorrectCount,
      currentExplanation: questions[currentIndex].explanation,
      showExplanation: true
    });
  },

  // 下一题
  nextQuestion() {
    const { currentIndex, gameMode } = this.data;
    const nextIndex = currentIndex + 1;
    
    // 根据游戏模式判断是否还有下一题
    if (gameMode === 'quiz') {
      const { questions } = this.data;
      if (nextIndex < questions.length) {
        this.setData({
          currentIndex: nextIndex,
          result: '',
          answered: false,
          showNextButton: false,
          selectedIndex: -1,
          isCorrect: false,
          showExplanation: false
        });
      } else {
        this.calculateResults();
        this.setData({
          gameCompleted: true
        });
      }
    } else {
      // 发音测评模式
      if (nextIndex < this.speechQuestions.length) {
        this.setData({
          currentIndex: nextIndex,
          showNextButton: false,
          showEvaluationResult: false,
          evaluationScore: 0,
          evaluationFeedback: ''
        });
      } else {
        this.calculateSpeechResults();
        this.setData({
          gameCompleted: true
        });
      }
    }
  },

  // 切换游戏模式
  switchMode(e) {
    const mode = e.currentTarget.dataset.mode;
    this.setData({
      gameMode: mode,
      currentIndex: 0,
      result: '',
      answered: false,
      showNextButton: false,
      gameCompleted: false,
      selectedIndex: -1,
      isCorrect: false,
      score: 0,
      correctCount: 0,
      incorrectCount: 0,
      currentExplanation: '',
      showExplanation: false,
      isRecording: false,
      isEvaluating: false,
      showEvaluationResult: false,
      evaluationScore: 0,
      evaluationFeedback: ''
    });
  },

  // 切换录音状态
  toggleSpeechRecording() {
    const { isRecording, isEvaluating } = this.data;
    
    if (isEvaluating) return;
    
    if (!isRecording) {
      // 开始录音
      this.setData({
        isRecording: true,
        showEvaluationResult: false
      });
      wx.showToast({
        title: '开始录音',
        icon: 'none'
      });
    } else {
      // 停止录音并进行评估
      this.setData({
        isRecording: false,
        isEvaluating: true
      });
      wx.showToast({
        title: '停止录音，正在评估...',
        icon: 'none'
      });
      
      // 模拟评估过程
      setTimeout(() => {
        this.evaluateSpeech();
      }, 2000);
    }
  },

  // 评估发音（模拟）
  evaluateSpeech() {
    console.log('[Game] 开始发音评测');

    const score = 80 + Math.floor(Math.random() * 21);

    let feedback = '';
    let details = '';

    if (score >= 95) {
      feedback = '发音非常标准！你是地道的四川人吧？';
      details = '声调准确、咬字清晰、韵味十足！';
    } else if (score >= 90) {
      feedback = '发音很标准，继续保持！';
      details = '整体发音很好，个别字音可以更地道一些。';
    } else if (score >= 85) {
      feedback = '发音不错，有一点地方可以改进。';
      details = '声调基本准确，但部分字音的方言特色还不够明显。';
    } else {
      feedback = '发音还可以，多练习会更地道哦！';
      details = '继续练习，注意方言的声调和特殊发音。';
    }

    const newScore = this.data.score + score;

    this.setData({
      isEvaluating: false,
      showEvaluationResult: true,
      evaluationScore: score,
      evaluationFeedback: feedback,
      evaluationDetails: details,
      showNextButton: true,
      score: newScore
    });

    console.log('[Game] 评测完成，得分:', score);
  },

  // 计算知识问答游戏结果
  calculateResults() {
    const { correctCount, questions } = this.data;
    const accuracy = Math.round((correctCount / questions.length) * 100);
    // 模拟排名数据
    const ranking = Math.max(1, 100 - Math.floor(Math.random() * 50));
    
    // 根据得分设置奖牌
    let medalImage = '';
    let medalText = '';
    
    if (this.data.score >= 90) {
      medalImage = 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p1.jpg'; // 金牌
      medalText = '方言大师';
    } else if (this.data.score >= 70) {
      medalImage = 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p2.jpg'; // 银牌
      medalText = '方言达人';
    } else if (this.data.score >= 50) {
      medalImage = 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p3.jpg'; // 铜牌
      medalText = '方言新手';
    } else {
      medalImage = 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p4.png'; // 鼓励奖
      medalText = '继续努力';
    }
    
    this.setData({
      accuracy: accuracy,
      ranking: ranking,
      medalImage: medalImage,
      medalText: medalText
    });
  },
  
  // 计算发音测评游戏结果
  calculateSpeechResults() {
    // 发音测评总分是5题的平均分
    const averageScore = Math.round(this.data.score / this.speechQuestions.length);
    // 模拟排名数据
    const ranking = Math.max(1, 100 - Math.floor(Math.random() * 50));
    
    // 根据平均得分设置奖牌
    let medalImage = '';
    let medalText = '';
    
    if (averageScore >= 95) {
      medalImage = 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p1.jpg'; // 金牌
      medalText = '方言发音大师';
    } else if (averageScore >= 90) {
      medalImage = 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p2.jpg'; // 银牌
      medalText = '方言发音达人';
    } else if (averageScore >= 85) {
      medalImage = 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p3.jpg'; // 铜牌
      medalText = '方言发音能手';
    } else {
      medalImage = 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p4.png'; // 鼓励奖
      medalText = '发音小能手';
    }
    
    this.setData({
      accuracy: averageScore, // 在发音测评中表示平均得分
      ranking: ranking,
      medalImage: medalImage,
      medalText: medalText,
      score: averageScore // 更新总分为平均分
    });
  },

  // 重新开始游戏
  restartGame() {
    this.setData({
      currentIndex: 0,
      result: '',
      answered: false,
      showNextButton: false,
      gameCompleted: false,
      selectedIndex: -1,
      isCorrect: false,
      score: 0,
      correctCount: 0,
      incorrectCount: 0,
      currentExplanation: '',
      showExplanation: false,
      isRecording: false,
      isEvaluating: false,
      showEvaluationResult: false,
      evaluationScore: 0,
      evaluationFeedback: ''
    });
  },

  // 返回首页
  backToHome() {
    wx.navigateTo({
      url: '/pages/index/index'
    });
  },

  // 分享游戏
  shareGame() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
  }
})