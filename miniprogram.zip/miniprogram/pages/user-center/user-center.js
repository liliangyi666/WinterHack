Page({
  data: {
    // 成就数据
    achievements: [
      // 对话类成就
      {
        id: 1,
        title: '初次对话',
        description: '完成第一次方言对话',
        category: '对话',
        rarity: 'common',
        icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/%E5%9B%BE1.png',
        reward: 10,
        completed: true,
        date: '2024-06-15'
      },
      {
        id: 2,
        title: '方言达人',
        description: '与虚拟人完成10次对话',
        category: '对话',
        rarity: 'rare',
        icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p2.jpg',
        reward: 50,
        progress: {
          current: 3,
          target: 10
        },
        completed: false
      },
      {
        id: 3,
        title: '语言大师',
        description: '与虚拟人完成50次对话',
        category: '对话',
        rarity: 'epic',
        icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p3.jpg',
        reward: 200,
        progress: {
          current: 0,
          target: 50
        },
        completed: false
      },
      {
        id: 4,
        title: '方言收藏家',
        description: '使用过5种不同的方言进行对话',
        category: '对话',
        rarity: 'legendary',
        icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p4.png',
        reward: 500,
        progress: {
          current: 1,
          target: 5
        },
        completed: false
      },
      
      // 游戏类成就
      {
        id: 5,
        title: '初次挑战',
        description: '完成第一次方言小游戏',
        category: '游戏',
        rarity: 'common',
        icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p1.jpg',
        reward: 20,
        completed: true,
        date: '2024-06-16'
      },
      {
        id: 6,
        title: '满分达人',
        description: '在方言小游戏中获得满分',
        category: '游戏',
        rarity: 'rare',
        icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p2.jpg',
        reward: 100,
        completed: false
      },
      {
        id: 7,
        title: '游戏之王',
        description: '完成10次方言小游戏',
        category: '游戏',
        rarity: 'epic',
        icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p3.jpg',
        reward: 300,
        progress: {
          current: 1,
          target: 10
        },
        completed: false
      },
      
      // 故事类成就
      {
        id: 8,
        title: '故事启蒙',
        description: '收听第一个方言故事',
        category: '故事',
        rarity: 'common',
        icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p1.jpg',
        reward: 15,
        completed: true,
        date: '2024-06-17'
      },
      {
        id: 9,
        title: '故事爱好者',
        description: '收听5个方言故事',
        category: '故事',
        rarity: 'rare',
        icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p2.jpg',
        reward: 75,
        progress: {
          current: 2,
          target: 5
        },
        completed: false
      },
      {
        id: 10,
        title: '故事收藏家',
        description: '收听所有方言故事',
        category: '故事',
        rarity: 'legendary',
        icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p4.png',
        reward: 400,
        progress: {
          current: 2,
          target: 6
        },
        completed: false
      },
      
      // 综合类成就
      {
        id: 11,
        title: '注册用户',
        description: '成功注册并登录',
        category: '综合',
        rarity: 'common',
        icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p1.jpg',
        reward: 50,
        completed: true,
        date: '2024-06-15'
      },
      {
        id: 12,
        title: '每日签到',
        description: '连续签到7天',
        category: '综合',
        rarity: 'epic',
        icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p3.jpg',
        reward: 300,
        progress: {
          current: 3,
          target: 7
        },
        completed: false
      },
      {
        id: 13,
        title: '分享达人',
        description: '分享应用给5位好友',
        category: '综合',
        rarity: 'rare',
        icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p2.jpg',
        reward: 150,
        progress: {
          current: 0,
          target: 5
        },
        completed: false
      },
      {
        id: 14,
        title: '学习达人',
        description: '连续学习方言30天',
        category: '综合',
        rarity: 'legendary',
        icon: 'https://cdn.jsdelivr.net/gh/evsong/bupt/assets/images/p4.png',
        reward: 1000,
        progress: {
          current: 5,
          target: 30
        },
        completed: false
      }
    ],
    
    // 分类相关
    categories: ['全部', '对话', '游戏', '故事', '综合'],
    activeCategory: '全部',
    filteredAchievements: [],
    
    // 统计数据
    totalAchievements: 0,
    completedAchievements: 0,
    progressPercentage: 0,
    
    // 详情弹窗
    showDetail: false,
    selectedAchievement: {},
    
    // 最近解锁的成就
    recentUnlocks: []
  },

  onLoad() {
    this.initAchievements();
  },

  // 初始化成就数据
  initAchievements() {
    const { achievements } = this.data;
    
    // 计算统计数据
    const totalAchievements = achievements.length;
    const completedAchievements = achievements.filter(ach => ach.completed).length;
    const progressPercentage = Math.round((completedAchievements / totalAchievements) * 100);
    
    // 获取最近解锁的成就（按时间倒序排列）
    const recentUnlocks = achievements
      .filter(ach => ach.completed)
      .sort((a, b) => new Date(b.date) - new Date(a.date))
      .slice(0, 3);
    
    // 初始显示所有成就
    this.setData({
      totalAchievements,
      completedAchievements,
      progressPercentage,
      filteredAchievements: achievements,
      recentUnlocks
    });
  },

  // 切换分类
  switchCategory(e) {
    const { category } = e.currentTarget.dataset;
    const { achievements } = this.data;
    
    let filteredAchievements = achievements;
    if (category !== '全部') {
      filteredAchievements = achievements.filter(ach => ach.category === category);
    }
    
    this.setData({
      activeCategory: category,
      filteredAchievements
    });
  },

  // 显示成就详情
  showAchievementDetail(e) {
    const { id } = e.currentTarget.dataset;
    const achievement = this.data.achievements.find(ach => ach.id === id);
    
    this.setData({
      showDetail: true,
      selectedAchievement: achievement
    });
  },

  // 关闭成就详情
  closeDetail() {
    this.setData({
      showDetail: false,
      selectedAchievement: {}
    });
  },

  // 返回首页
  backToHome() {
    wx.navigateTo({
      url: '/pages/index/index'
    });
  }
});