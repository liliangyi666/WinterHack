const OmniWebSocket = require('./utils/omni-websocket.js');
const OmniAudioManager = require('./utils/omni-audio.js');

App({
  // 全局单例 WebSocket 和 AudioManager
  globalOmniWS: null,
  globalAudioManager: null,
  omniInitialized: false,

  onLaunch() {
    console.log("小程序启动");
  },

  onHide() {
    console.log("小程序进入后台");
    // 小程序进入后台时不清理连接，保持连接以便快速返回
  },

  onShow() {
    console.log("小程序从后台进入前台");
    // 检查连接状态，如果断开可以尝试重连
  },

  /**
   * 获取或创建全局 Omni WebSocket 连接
   * @param {string} dialectType - 方言类型
   * @param {string} voice - 音色
   * @returns {Promise<Object>} {omniWS, audioManager}
   */
  async getOmniConnection(dialectType = '四川话', voice = 'Sunny') {
    // 如果已经初始化且连接正常，直接返回
    if (this.omniInitialized && this.globalOmniWS && this.globalOmniWS.isConnected) {
      console.log('[App] 使用已有的Omni连接');
      return {
        omniWS: this.globalOmniWS,
        audioManager: this.globalAudioManager
      };
    }

    // 清理旧连接
    if (this.globalOmniWS) {
      console.log('[App] 清理旧的Omni连接');
      this.globalOmniWS.close();
      this.globalOmniWS = null;
    }

    // 创建新连接
    console.log('[App] 创建新的Omni连接');

    const voiceMap = {
      '普通话': 'Katerina',  // 标准普通话女声
      '四川话': 'Sunny',
      '上海话': 'Jada',
      '广东话': 'Kiki',
      '闽南语': 'Roy',
      '北京话': 'Dylan',
      '南京话': 'Li',
      '陕西话': 'Marcus',
      '天津话': 'Peter'
    };

    const wsUrl = 'ws://localhost:8000/ws/omni';
    // const wsUrl = 'wss://smart-cooks-scream.loca.lt/ws/omni'; // 生产环境

    this.globalOmniWS = new OmniWebSocket({ url: wsUrl });

    try {
      await this.globalOmniWS.connect(dialectType, voiceMap[dialectType] || voice);

      // 创建音频管理器
      this.globalAudioManager = new OmniAudioManager(this.globalOmniWS);

      this.omniInitialized = true;

      console.log('[App] Omni连接创建成功');

      return {
        omniWS: this.globalOmniWS,
        audioManager: this.globalAudioManager
      };

    } catch (err) {
      console.error('[App] Omni连接创建失败:', err);
      this.globalOmniWS = null;
      this.globalAudioManager = null;
      this.omniInitialized = false;
      throw err;
    }
  },

  /**
   * 清理全局 Omni 连接
   */
  cleanupOmniConnection() {
    console.log('[App] 清理全局Omni连接');

    if (this.globalAudioManager) {
      this.globalAudioManager.destroy();
      this.globalAudioManager = null;
    }

    if (this.globalOmniWS) {
      this.globalOmniWS.close();
      this.globalOmniWS = null;
    }

    this.omniInitialized = false;
  }
})
