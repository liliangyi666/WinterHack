/**
 * CDN 链接配置文件
 * 使用 jsDelivr 加速访问 GitHub 仓库资源
 *
 * 使用方法：
 * const CDN = require('./config-cdn.js');
 * const audioUrl = CDN.audio.story2;
 * const imageUrl = CDN.images.cover;
 */

const CDN_BASE = "https://cdn.jsdelivr.net/gh/evsong/bupt";

const CDN = {
  // 音频资源
  audio: {
    story2: `${CDN_BASE}/assets/audio/story2.mp3`,
    story3: `${CDN_BASE}/assets/audio/story3.mp3`,
    story4: `${CDN_BASE}/assets/audio/story4.mp3`,
  },

  // 图片资源
  images: {
    // 基础图片
    p1: `${CDN_BASE}/assets/images/p1.jpg`,
    p2: `${CDN_BASE}/assets/images/p2.jpg`,
    p3: `${CDN_BASE}/assets/images/p3.jpg`,
    p4: `${CDN_BASE}/assets/images/p4.png`,
    userAvatar: `${CDN_BASE}/assets/images/user-avatar.svg`,

    // 地图与省份
    china: `${CDN_BASE}/assets/images/%E4%B8%AD%E5%9B%BD.png`,
    sichuan: `${CDN_BASE}/assets/images/%E5%9B%9B%E5%B7%9D.png`,
    hunan: `${CDN_BASE}/assets/images/%E6%B9%96%E5%8D%97.png`,
    henan: `${CDN_BASE}/assets/images/%E6%B2%B3%E5%8D%97.png`,
    jiangxi: `${CDN_BASE}/assets/images/%E6%B1%9F%E8%A5%BF.png`,

    // 装饰 - 灯
    lamp1: `${CDN_BASE}/assets/images/%E7%81%AF1.png`,
    lamp2: `${CDN_BASE}/assets/images/%E7%81%AF2.png`,
    lamp3: `${CDN_BASE}/assets/images/%E7%81%AF3.png`,
    lamp4: `${CDN_BASE}/assets/images/%E7%81%AF4.png`,

    // 装饰 - 书
    book1: `${CDN_BASE}/assets/images/%E4%B9%A61.png`,
    book2: `${CDN_BASE}/assets/images/%E4%B9%A62.png`,
    book3: `${CDN_BASE}/assets/images/%E4%B9%A63.png`,
    book4: `${CDN_BASE}/assets/images/%E4%B9%A64.png`,

    // 装饰 - 竹
    bamboo1: `${CDN_BASE}/assets/images/%E7%AB%B91.png`,
    bamboo2: `${CDN_BASE}/assets/images/%E7%AB%B92.png`,
    bamboo3: `${CDN_BASE}/assets/images/%E7%AB%B93.png`,
    bamboo4: `${CDN_BASE}/assets/images/%E7%AB%B94.png`,

    // 装饰 - 钱
    coin1: `${CDN_BASE}/assets/images/%E9%92%B11.png`,
    coin2: `${CDN_BASE}/assets/images/%E9%92%B12.png`,
    coin3: `${CDN_BASE}/assets/images/%E9%92%B13.png`,
    coin4: `${CDN_BASE}/assets/images/%E9%92%B14.png`,

    // 纹理
    pattern2: `${CDN_BASE}/assets/images/%E7%BA%B92.png`,
    pattern3: `${CDN_BASE}/assets/images/%E7%BA%B93.png`,
    pattern4: `${CDN_BASE}/assets/images/%E7%BA%B94.png`,
    pattern5_1: `${CDN_BASE}/assets/images/%E7%BA%B95%281%29.png`,
    pattern5_2: `${CDN_BASE}/assets/images/%E7%BA%B95%282%29.png`,

    // 背景与封面
    background: `${CDN_BASE}/assets/images/%E8%83%8C%E6%99%AF.jpg`,
    cover: `${CDN_BASE}/assets/images/%E5%B0%81%E9%9D%A2.gif`,

    // 文化主题
    chineseBuilding: `${CDN_BASE}/assets/images/%E4%B8%AD%E5%9B%BD%E9%A3%8E%E5%BB%BA%E7%AD%91.png`,
    duanwuEgg: `${CDN_BASE}/assets/images/%E7%AB%AF%E5%8D%88%E7%9A%84%E9%B8%AD%E8%9B%8B.png`,
    henanIronFlower: `${CDN_BASE}/assets/images/%E6%B2%B3%E5%8D%97%E6%89%93%E9%93%81%E8%8A%B1.png`,
    orangeFireworks: `${CDN_BASE}/assets/images/%E6%A9%98%E5%AD%90%E6%B4%B2%E7%83%9F%E8%8A%B1.jpg`,
    xiangxiCorpse: `${CDN_BASE}/assets/images/%E6%B9%98%E8%A5%BF%E8%B5%B6%E5%B0%B8.jpg`,

    // 其他
    figure1: `${CDN_BASE}/assets/images/%E5%9B%BE1.png`,
    game: `${CDN_BASE}/assets/images/%E6%B8%B8%E6%88%8F.jpg`,
  },

  // 视频资源
  video: {
    video1: `${CDN_BASE}/assets/video/1.mp4`,
    dialectToMandarin: `${CDN_BASE}/assets/video/DialectToMandarin.mp4`,
  },

  // 工具函数：获取任意资源的 CDN 链接
  get(path) {
    // 如果是相对路径，自动添加基础 URL
    if (path.startsWith('/assets/')) {
      return `${CDN_BASE}${path}`;
    }
    if (path.startsWith('assets/')) {
      return `${CDN_BASE}/${path}`;
    }
    return path;
  },

  // 批量转换路径数组
  batchGet(paths) {
    return paths.map(path => this.get(path));
  }
};

// 导出配置
module.exports = CDN;
